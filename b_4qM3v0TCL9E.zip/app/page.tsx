"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import { ChevronRight, RotateCcw, Sparkles, User, Heart } from "lucide-react"

const data: Record<string, string[]> = {
  외모: [
    "정말 상관없음",
    "안되는 사람은 있지만 안보는 편임",
    "평범하게 생기면 됐음",
    "훈훈하게 생김",
    "얼굴이 최고야",
  ],
  키: [
    "나보다 작아도 됨",
    "나보다 1CM라도 크기만 하면 됨",
    "나보다 크게 느껴지면 됨",
    "평균 이상은 넘었으면",
    "180CM 이상",
  ],
  자기관리: [
    "잘 못해도 됨",
    "노력하려는 의지만 있으면 됨",
    "적당히 청결하고 평범한 정도",
    "꾸준한 운동은 해야 함",
    "자기 자신을 잘 가꾸는 사람",
  ],
  패션센스: [
    "꽝이어도 됨",
    "관심만 있으면 됨",
    "튀지 않고 무난하게",
    "관심 많고 잘 꾸미는 정도",
    "시선이 갈 정도로 잘입는 사람",
  ],
  사회성: [
    "음..내가 처음부터 가르쳐줄 수 있음",
    "가끔 잉 하지만 기본은 있음",
    "적당함",
    "두루 잘 지내는 인싸임",
    "어디 가서 자랑하고 싶음",
  ],
  눈치: [
    "꽝이어도 됨",
    "약간 모자라서 잉 할 때가 종종 있음",
    "가끔 실망하지만 가르쳐주면 됨",
    "평균 이상, 만족할만한 수준",
    "내가 얘한테 배움",
  ],
  경제력: [
    "심각하지만 내가 도와줄게",
    "노란불이 들어오지만 같이 훈련해보자",
    "막쓰지도 안쓰지도 않음",
    "경제 관념이 확실히 있고, 써야할 때를 앎",
    "얘한테 내 자산 맡기고 싶음",
  ],
  신앙심: [
    "비신자",
    "교회는 다니지만 잘 모르겠음",
    "제자훈련 이상",
    "신앙적인 가치관이 통함",
    "존경심이 듦",
  ],
  비전: [
    "아무 생각 없음",
    "찾아나서는 중임",
    "방향성은 있음",
    "비전이 뚜렷하고, 실천하고 있음",
    "이 사람만 따라가면 될 것 같음",
  ],
  연애스타일: [
    "모솔 느낌 남",
    "모솔 느낌 나지만 한 세번 말하면 그래도 고침",
    "풋풋하게 연애하고, 싸우기도 하고",
    "마음 너무 잘 이해해줌",
    "오직 나만 바라봐주고, 나에게 맞춰주는 사람",
  ],
  똑똒함: [
    "건강하면 됐어",
    "답답할 때가 있지만 말은 통함",
    "평균",
    "똑똒하다 느껴짐",
    "존경스러움",
  ],
  성실도: [
    "게으른 편",
    "필요할 때만 함",
    "평균적인 수준",
    "꾸준히 노력하는 편",
    "자기관리 + 성실함 모두 갖춤",
  ],
}

const categories = Object.keys(data)

type Step = "self" | "partner" | "result"

export default function TalentTest() {
  const [step, setStep] = useState<Step>("self")
  const [selfScores, setSelfScores] = useState<Record<string, number>>({})
  const [partnerScores, setPartnerScores] = useState<Record<string, number>>({})

  const myTotal = Object.values(selfScores).reduce((a, b) => a + b, 0)
  const partnerTotal = Object.values(partnerScores).reduce((a, b) => a + b, 0)
  const remaining = myTotal - partnerTotal

  const handleSelfSelect = (category: string, value: number) => {
    setSelfScores((prev) => ({ ...prev, [category]: value }))
  }

  const handlePartnerSelect = (category: string, value: number) => {
    const newPartnerScores = { ...partnerScores, [category]: value }
    const newTotal = Object.values(newPartnerScores).reduce((a, b) => a + b, 0)
    
    if (newTotal <= myTotal || partnerScores[category]) {
      setPartnerScores(newPartnerScores)
    }
  }

  const goToPartner = () => {
    if (Object.keys(selfScores).length === categories.length) {
      setStep("partner")
    }
  }

  const goToResult = () => {
    if (Object.keys(partnerScores).length === categories.length) {
      setStep("result")
    }
  }

  const reset = () => {
    setStep("self")
    setSelfScores({})
    setPartnerScores({})
  }

  const getResultMessage = () => {
    if (partnerTotal > myTotal) return { emoji: "🔥", text: "기준이 높습니다!", subtext: "이상형에 대한 기대치가 본인보다 높아요" }
    if (partnerTotal === myTotal) return { emoji: "👌", text: "균형 잡힌 기준!", subtext: "현실적이고 균형 잡힌 이상형을 원해요" }
    return { emoji: "😎", text: "여유로운 마음!", subtext: "상대방에게 여유로운 기준을 가지고 있어요" }
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-rose-50 to-white py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-rose-100 text-rose-700 rounded-full text-sm font-medium mb-4">
            <Sparkles className="w-4 h-4" />
            이상형 달란트 테스트
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2 text-balance">
            {step === "self" && "나의 수준을 평가해주세요"}
            {step === "partner" && "이상형을 선택해주세요"}
            {step === "result" && "테스트 결과"}
          </h1>
          {step === "partner" && (
            <div className="mt-4 inline-flex items-center gap-3 px-6 py-3 bg-white rounded-2xl shadow-sm border border-rose-100">
              <span className="text-gray-600 text-sm">남은 달란트</span>
              <span className={cn(
                "text-2xl font-bold",
                remaining > 10 ? "text-emerald-600" : remaining > 0 ? "text-amber-600" : "text-rose-600"
              )}>
                {remaining}
              </span>
            </div>
          )}
        </div>

        {/* Progress indicator */}
        {step !== "result" && (
          <div className="flex items-center justify-center gap-2 mb-8">
            <div className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all",
              step === "self" ? "bg-rose-500 text-white" : "bg-rose-100 text-rose-700"
            )}>
              <User className="w-4 h-4" />
              나의 수준
            </div>
            <ChevronRight className="w-4 h-4 text-gray-400" />
            <div className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all",
              step === "partner" ? "bg-rose-500 text-white" : "bg-gray-100 text-gray-500"
            )}>
              <Heart className="w-4 h-4" />
              이상형
            </div>
          </div>
        )}

        {/* Step 1: Self Assessment */}
        {step === "self" && (
          <div className="space-y-4">
            {categories.map((category) => (
              <Card key={category} className="overflow-hidden border-0 shadow-sm">
                <CardHeader className="pb-2 bg-gradient-to-r from-rose-50 to-pink-50">
                  <CardTitle className="text-lg font-semibold text-gray-800">{category}</CardTitle>
                </CardHeader>
                <CardContent className="p-3 space-y-2">
                  {data[category].map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleSelfSelect(category, index + 1)}
                      className={cn(
                        "w-full text-left px-4 py-3 rounded-xl text-sm transition-all",
                        selfScores[category] === index + 1
                          ? "bg-rose-500 text-white shadow-md"
                          : "bg-gray-50 hover:bg-gray-100 text-gray-700"
                      )}
                    >
                      <span className="font-medium mr-2">{index + 1}.</span>
                      {option}
                    </button>
                  ))}
                </CardContent>
              </Card>
            ))}
            <Button
              onClick={goToPartner}
              disabled={Object.keys(selfScores).length !== categories.length}
              className="w-full h-14 text-lg bg-rose-500 hover:bg-rose-600 rounded-2xl mt-6"
            >
              다음 단계로
              <ChevronRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        )}

        {/* Step 2: Partner Selection */}
        {step === "partner" && (
          <div className="space-y-4">
            {categories.map((category) => (
              <Card key={category} className="overflow-hidden border-0 shadow-sm">
                <CardHeader className="pb-2 bg-gradient-to-r from-pink-50 to-rose-50">
                  <CardTitle className="text-lg font-semibold text-gray-800">{category}</CardTitle>
                </CardHeader>
                <CardContent className="p-3 space-y-2">
                  {data[category].map((option, index) => {
                    const value = index + 1
                    const wouldExceed = !partnerScores[category] && (partnerTotal + value > myTotal)
                    const isSelected = partnerScores[category] === value
                    
                    return (
                      <button
                        key={index}
                        onClick={() => handlePartnerSelect(category, value)}
                        disabled={wouldExceed && !isSelected}
                        className={cn(
                          "w-full text-left px-4 py-3 rounded-xl text-sm transition-all",
                          isSelected
                            ? "bg-pink-500 text-white shadow-md"
                            : wouldExceed
                            ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                            : "bg-gray-50 hover:bg-gray-100 text-gray-700"
                        )}
                      >
                        <span className="font-medium mr-2">{value}.</span>
                        {option}
                      </button>
                    )
                  })}
                </CardContent>
              </Card>
            ))}
            <Button
              onClick={goToResult}
              disabled={Object.keys(partnerScores).length !== categories.length}
              className="w-full h-14 text-lg bg-pink-500 hover:bg-pink-600 rounded-2xl mt-6"
            >
              결과 보기
              <Sparkles className="ml-2 w-5 h-5" />
            </Button>
          </div>
        )}

        {/* Result Page */}
        {step === "result" && (
          <div className="space-y-6">
            {/* Summary */}
            <Card className="border-0 shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-rose-500 to-pink-500 p-6 text-white text-center">
                <div className="text-6xl mb-2">{getResultMessage().emoji}</div>
                <h2 className="text-2xl font-bold">{getResultMessage().text}</h2>
                <p className="text-rose-100 mt-1">{getResultMessage().subtext}</p>
              </div>
              <CardContent className="p-6">
                <div className="flex justify-around text-center">
                  <div>
                    <div className="text-sm text-gray-500 mb-1">내 달란트</div>
                    <div className="text-3xl font-bold text-emerald-600">{myTotal}</div>
                  </div>
                  <div className="w-px bg-gray-200" />
                  <div>
                    <div className="text-sm text-gray-500 mb-1">이상형</div>
                    <div className="text-3xl font-bold text-pink-600">{partnerTotal}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Category Comparison */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">항목별 비교</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {categories.map((category) => {
                  const diff = (partnerScores[category] || 0) - (selfScores[category] || 0)
                  const isDanger = diff >= 2
                  
                  return (
                    <div
                      key={category}
                      className={cn(
                        "p-4 rounded-xl transition-all",
                        isDanger ? "bg-red-50 border-2 border-red-200" : "bg-gray-50"
                      )}
                    >
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-800">{category}</span>
                        {isDanger && (
                          <span className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded-full">
                            기대치 높음
                          </span>
                        )}
                      </div>
                      <div className="flex gap-2 items-center">
                        <div className="flex-1">
                          <div className="flex gap-1 h-3">
                            <div
                              className="bg-emerald-500 rounded-full transition-all"
                              style={{ width: `${(selfScores[category] || 0) * 20}%` }}
                            />
                          </div>
                          <div className="text-xs text-gray-500 mt-1">나 ({selfScores[category]})</div>
                        </div>
                        <div className="flex-1">
                          <div className="flex gap-1 h-3">
                            <div
                              className="bg-pink-500 rounded-full transition-all"
                              style={{ width: `${(partnerScores[category] || 0) * 20}%` }}
                            />
                          </div>
                          <div className="text-xs text-gray-500 mt-1">이상형 ({partnerScores[category]})</div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </CardContent>
            </Card>

            <Button
              onClick={reset}
              variant="outline"
              className="w-full h-14 text-lg rounded-2xl"
            >
              <RotateCcw className="mr-2 w-5 h-5" />
              다시 테스트하기
            </Button>
          </div>
        )}
      </div>
    </main>
  )
}
